<?
	class DemoQuotes extends BigTreeModule {

		var $Table = "demo_quotes";
		var $Module = "2";
	}
?>
