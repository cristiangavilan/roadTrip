<? include "_header.php" ?>
<?=$bigtree["content"]?>
<? include "_footer.php" ?>