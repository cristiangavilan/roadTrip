<?
	/*
		Resources Available:
		"title" = Title - Text
		"content" = Content - html
	*/
?>
<div class="mobile-full tablet-4 tablet-push-1 desktop-6 desktop-push-3">
	<div class="callout">
		<hr />
		<h4><?=$callout["title"]?></h4>
		<?=$callout["content"]?>
		<hr />
	</div>
</div>