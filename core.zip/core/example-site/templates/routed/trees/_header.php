<?
	$treesMod = new DemoTrees;	
?>