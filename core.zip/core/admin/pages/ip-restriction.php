<h1>Access Denied</h1>
<form method="post" action="" class="module">
	<p class="error_message clear">Your IP address is either banned or not in the allowed IP ranges.</p>
	<fieldset>
		<p>Please contact your web master if you believe this is in error.</p>
	</fieldset>
	<br />
</form>