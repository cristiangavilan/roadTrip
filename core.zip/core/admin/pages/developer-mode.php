<?
	$bigtree["layout"] = "login";
	$site = $cms->getPage(0,false);
?>
<form method="post" action="" class="maintenance">
	<fieldset>
		<h2><span class="vitals"></span>Maintenance Underway</h2>
		<p class="notice">We are currently undergoing site maintenance. If your need is urgent, please contact your webmaster.</p>
	</fieldset>
</form>