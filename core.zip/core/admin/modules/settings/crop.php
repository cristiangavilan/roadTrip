<?
	$bigtree["form_root"] = ADMIN_ROOT."settings/";
	include BigTree::path("admin/auto-modules/forms/crop.php");
?>