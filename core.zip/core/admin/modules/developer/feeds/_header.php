<?
	$feed_types = array(
		"custom" => "Custom",
		"rss" => "RSS 0.91",
		"rss2" => "RSS 2.0"
	);
?>