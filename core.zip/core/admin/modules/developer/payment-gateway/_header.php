<?
	$gateway = new BigTreePaymentGateway;
?>