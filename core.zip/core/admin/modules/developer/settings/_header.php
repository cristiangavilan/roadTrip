<?
	$t = $admin->getCachedFieldTypes(true);
	$types = $t["settings"];
?>