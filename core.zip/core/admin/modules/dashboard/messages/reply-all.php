<?
	$reply_all = true;
	include BigTree::path("admin/modules/dashboard/messages/reply.php");
?>