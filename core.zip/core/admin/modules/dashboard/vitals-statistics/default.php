<?
	$root = ADMIN_ROOT."dashboard/vitals-statistics/";
?>
<div class="developer">
	<div class="table">
		<section>
			<a class="box_select" href="<?=$root?>analytics/">
				<span class="analytics"></span>
				<p>Analytics</p>
			</a>
			
			<a class="box_select" href="<?=$root?>404/">
				<span class="page_404"></span>
				<p>404 Report</p>
			</a>
			
			<a class="box_select" href="<?=$root?>integrity/">
				<span class="integrity"></span>
				<p>Integrity Check</p>
			</a>
		</section>
	</div>
</div>