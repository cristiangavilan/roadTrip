<div id="login">
	<form method="post" action="" class="module">
		<h2>Password Set</h2>
		<fieldset class="clear">
			<p>Your password has been successfully updated. <a href="<?=$login_root?>">Click Here</a> to login with your new password.</p>
		</fieldset>
		<br />
	</form>
</div>