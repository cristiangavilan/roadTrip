<?
	$admin->logout();
?>