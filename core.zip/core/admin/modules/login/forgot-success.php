<div id="login">
	<form method="post" action="" class="module ">
		<h2>Check Your Email</h2>
		<fieldset class="clear">
			<p>A link to change your password has been emailed to you.</p>
		</fieldset>
		<br />
	</form>
</div>