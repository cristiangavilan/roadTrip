<script>parent.BigTreeBar.refresh("<?=base64_decode(end($bigtree["path"]))?>");</script>
<? die() ?>