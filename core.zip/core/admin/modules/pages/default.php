<?
	BigTree::redirect(ADMIN_ROOT."pages/view-tree/0/");
?>