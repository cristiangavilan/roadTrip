<?
	$admin->requireLevel(2);
?>