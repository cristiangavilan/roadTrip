<fieldset class="last">
	<label>Fields To Pull Address From <small>(comma separated)</small></label>
	<input type="text" name="fields" value="<?=$data["fields"]?>" />
</fieldset>