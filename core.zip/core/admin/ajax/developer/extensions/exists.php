<?
	echo BigTree::curl("http://www.bigtreecms.org/ajax/extensions/exists/?id=".urlencode($_GET["id"]));
?>