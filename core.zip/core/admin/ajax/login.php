<?
	header("Content-type: text/javascript");
?>
BigTree.growl("Error","You have been signed out.");