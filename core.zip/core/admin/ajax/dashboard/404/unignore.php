<?
	header("Content-type: text/javascript");
	$admin->unignore404($_POST["id"]);
?>