<?
	header("Content-type: text/javascript");
	$admin->delete404($_POST["id"]);
?>