<!doctype html>
<html>
	<head>
		<title>File Browser</title>
		<script src="<?=ADMIN_ROOT?>js/tiny_mce/tiny_mce_popup.js"></script>
		<script src="<?=ADMIN_ROOT?>js/lib.js"></script>
		<script src="<?=ADMIN_ROOT?>js/file-browser.js"></script>
	</head>
	<body>
		<a href="javascript:FileBrowserDialogue.mySubmit();">Submit</a>
	</body>
</html>