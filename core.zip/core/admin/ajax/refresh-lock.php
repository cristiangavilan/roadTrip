<?
	$admin->refreshLock($_POST["table"],$_POST["id"]);
?>