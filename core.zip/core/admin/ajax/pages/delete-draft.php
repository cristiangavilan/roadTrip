<?
	$admin->deletePageDraft($_GET["id"]);
?>