<?
	$admin->deletePageRevision($_GET["id"]);
?>