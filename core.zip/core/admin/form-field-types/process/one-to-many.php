<?
	$field["output"] = $field["input"];
?>