<?
	$field["output"] = BigTree::dateFormat($field["input"],"Y-m-d");
?>