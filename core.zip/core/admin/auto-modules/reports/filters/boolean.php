<select name="<?=$id?>">
	<option>Both</option>
	<option>Yes</option>
	<option>No</option>
</select>