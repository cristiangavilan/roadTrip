<div class="container">
	<section>
		<div class="alert">
			<span></span>
			<h3>Error</h3>
		</div>
		<p>
			You do not have permission to edit this entry.
		</p>
	</section>
	<footer>
		<a href="javascript:history.go(-1);" class="button white">Return</a>
	</footer>
</div>