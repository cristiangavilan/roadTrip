<?
	$server_root = str_replace("site/index.php","",strtr(__FILE__, "\\", "/"));	
	include "../core/launch.php";
?>